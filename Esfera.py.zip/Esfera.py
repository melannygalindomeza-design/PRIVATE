import math
radio = float(input("cual es el radio"))
area = 4* math.pi*(radio**2)
print (f"el area es:{radio:.2f}:)")
perimetro = 2*math.pi* (radio)
print (f"el perimetro es:{perimetro:.2f}:)")

print (f" el valor de pi:{math.pi}")
print (f"el numero de pi acortado es:{math.pi:.4}")

volumen = (4/3) * math.pi * (radio**3)
print (f"El volumen es:{volumen:.2f}")